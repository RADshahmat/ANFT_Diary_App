// config.dart
const String baseUrl = 'http://192.168.0.105/anft_diary_web/';
